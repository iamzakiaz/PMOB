package com.example.pmob7

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.androidnetworking.AndroidNetworking
import com.androidnetworking.common.Priority
import com.androidnetworking.interfaces.JSONArrayRequestListener
import com.androidnetworking.interfaces.JSONObjectRequestListener
import com.example.pmob7.databinding.ActivityMainBinding
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AndroidNetworking.initialize(applicationContext)
        val layoutManager = LinearLayoutManager(this)
        binding.rvEmployee.layoutManager = layoutManager

        AndroidNetworking.get("https://api-blue-archive.vercel.app/api/characters")
            .setPriority(Priority.MEDIUM)
            .build()
            .getAsJSONObject(object : JSONObjectRequestListener {
                override fun onResponse(response: JSONObject) {
                    // Tangani respons JSONArray di sini
                    val characterlist = mutableListOf<ModelKaryawan>()
                    val character = response.getJSONArray("data")
                    for (i in 0 until character.length()) {
                        val char = character.getJSONObject(i)
                        val charId = char.optString("_id")
                        val name = char.optString("name")
                        val schools = char.optString("school")
                        val birthday = char.optString("birthday")
                        val jurus = char.optString("damageType")
                        characterlist.add(ModelKaryawan(charId,name,schools,birthday,jurus))
                    }
                    val adapter = Adapter(characterlist)
                    binding.rvEmployee.adapter = adapter
                }
                override fun onError(anError: com.androidnetworking.error.ANError) {
                    // Tangani kesalahan di sini
                }
            })
    }
}