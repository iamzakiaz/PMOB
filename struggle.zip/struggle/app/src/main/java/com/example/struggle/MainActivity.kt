package com.example.struggle

//import android.os.Bundle
//import androidx.activity.enableEdgeToEdge
//import androidx.appcompat.app.AppCompatActivity
//import androidx.core.view.ViewCompat
//import androidx.core.view.WindowInsetsCompat

//class MainActivity : AppCompatActivity() {
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        enableEdgeToEdge()
//        setContentView(R.layout.activity_main)
//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
//            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
//            insets
//        }
//    }
//}
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private val students = mutableListOf<Student>()
    private lateinit var adapter: StudentAdapter
    private var nextId = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        val addButton: Button = findViewById(R.id.addButton)
        val nameEditText: EditText = findViewById(R.id.nameEditText)

        adapter = StudentAdapter(students, ::onEditStudent, ::onDeleteStudent)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        addButton.setOnClickListener {
            val name = nameEditText.text.toString()
            if (name.isBlank()) {
                Toast.makeText(this, "Nama tidak boleh kosong", Toast.LENGTH_SHORT).show()
            } else {
                students.add(Student(nextId++, name))
                adapter.notifyDataSetChanged()
                nameEditText.text.clear()
            }
        }
    }

    private fun onEditStudent(student: Student) {
        val input = EditText(this)
        input.setText(student.name)

        AlertDialog.Builder(this)
            .setTitle("Edit Nama")
            .setView(input)
            .setPositiveButton("Simpan") { _, _ ->
                student.name = input.text.toString()
                adapter.notifyDataSetChanged()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun onDeleteStudent(student: Student) {
        students.remove(student)
        adapter.notifyDataSetChanged()
    }
}
