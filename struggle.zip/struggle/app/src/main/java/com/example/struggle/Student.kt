package com.example.struggle

data class Student(
    var id: Int,
    var name: String
)
