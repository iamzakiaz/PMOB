package com.example.pertemuan9_nih

data class ModelPekerjaan(
    val nama: String? = null,
    val shift: String? =null,
    val photoUrl: String? =null,
)